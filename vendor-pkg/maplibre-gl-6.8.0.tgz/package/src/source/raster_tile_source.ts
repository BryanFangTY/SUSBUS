import {ensureError, extend, pick} from '../util/util.ts';

import {ImageRequest} from '../util/image_request.ts';

import {ResourceType} from '../util/request_manager.ts';
import {ErrorEvent, Evented} from '../util/evented.ts';
import {MapSourceDataEvent, type SourceEventType} from '../ui/events.ts';
import {loadTileJson} from './load_tilejson.ts';
import {TileBounds} from '../tile/tile_bounds.ts';
import {Texture} from '../webgl/texture.ts';
import {RGBAImage} from '../util/image.ts';
import {isAbortError} from '../util/abort_error.ts';

import type {Source} from './source.ts';
import type {OverscaledTileID} from '../tile/tile_id.ts';
import type {Map} from '../ui/map.ts';
import type {Dispatcher} from '../util/dispatcher.ts';
import type {Tile} from '../tile/tile.ts';
import type {
    RasterSourceSpecification,
    RasterDEMSourceSpecification
} from '@maplibre/maplibre-gl-style-spec';

/**
 * A source containing raster tiles (See the [raster source documentation](https://maplibre.org/maplibre-style-spec/sources/#raster) for detailed documentation of options.)
 *
 * @group Sources
 *
 * \> ℹ️ **Note:** The default `tileSize` is `512`. If your tile provider (such as OpenStreetMap or Stadia Maps) serves 256px tiles, set `tileSize: 256` manually to avoid blurry rendering due to upscaling.
 *
 * @example
 * ```ts
 * map.addSource('raster-source', {
 *     'type': 'raster',
 *     'tiles': ['https://tiles.stadiamaps.com/tiles/stamen_watercolor/{z}/{x}/{y}.jpg'],
 *     'tileSize': 256, // Set this to match tile server output to avoid blurry rendering
 * });
 * ```
 *
 * @example
 * ```ts
 * map.addSource('wms-test-source', {
 *      'type': 'raster',
 * // use the tiles option to specify a WMS tile source URL
 *      'tiles': [
 *          'https://img.nj.gov/imagerywms/Natural2015?bbox={bbox-epsg-3857}&format=image/png&service=WMS&version=1.1.1&request=GetMap&srs=EPSG:3857&transparent=true&width=256&height=256&layers=Natural2015'
 *      ],
 *      'tileSize': 256 // Important for WMS if tiles are 256px
 * });
 * ```
 * @see [Add a raster tile source](https://maplibre.org/maplibre-gl-js/docs/examples/map-tiles/)
 * @see [Add a WMS source](https://maplibre.org/maplibre-gl-js/docs/examples/add-a-wms-source/)
 * @see [Display a satellite map](https://maplibre.org/maplibre-gl-js/docs/examples/display-a-satellite-map/)
 */
export class RasterTileSource extends Evented<SourceEventType> implements Source {
    type: 'raster' | 'raster-dem';
    id: string;
    minzoom: number;
    maxzoom: number;
    url: string;
    scheme: string;
    tileSize: number;

    bounds: [number, number, number, number];
    tileBounds: TileBounds;
    roundZoom: boolean;
    dispatcher: Dispatcher;
    map: Map;
    tiles: string[];

    _loaded: boolean;
    _options: RasterSourceSpecification | RasterDEMSourceSpecification;
    _premultiplyAlpha: boolean;
    _tileJSONRequest: AbortController;

    constructor(id: string, options: RasterSourceSpecification | RasterDEMSourceSpecification, dispatcher: Dispatcher, eventedParent: Evented) {
        super();
        this.id = id;
        this.dispatcher = dispatcher;
        this.setEventedParent(eventedParent);

        this.type = 'raster';
        this.minzoom = 0;
        this.maxzoom = 22;
        this.roundZoom = true;
        this.scheme = 'xyz';
        this.tileSize = 512;
        this._loaded = false;
        this._premultiplyAlpha = true;

        this._options = extend({type: 'raster'}, options);
        extend(this, pick(options, ['url', 'scheme', 'tileSize']));
    }

    async load(sourceDataChanged: boolean = false): Promise<void> {
        this._loaded = false;
        this.fire(new MapSourceDataEvent('dataloading'));
        this._tileJSONRequest = new AbortController();
        try {
            const tileJSON = await loadTileJson(this._options, this.map._requestManager, this._tileJSONRequest, this.map._ownerWindow);
            this._tileJSONRequest = null;
            this._loaded = true;
            if (tileJSON) {
                extend(this, tileJSON);
                if (tileJSON.bounds) this.tileBounds = new TileBounds(tileJSON.bounds, this.minzoom, this.maxzoom);

                // `content` is included here to prevent a race condition where `Style._updateSources` is called
                // before the TileJSON arrives. this makes sure the tiles needed are loaded once TileJSON arrives
                // ref: https://github.com/mapbox/mapbox-gl-js/pull/4347#discussion_r104418088
                this.fire(new MapSourceDataEvent('data', {sourceDataType: 'metadata'}));
                this.fire(new MapSourceDataEvent('data', {sourceDataType: 'content', sourceDataChanged}));
            }
        } catch (err) {
            this._tileJSONRequest = null;
            this._loaded = true; // let's pretend it's loaded so the source will be ignored

            // only fire error event if it is not due to aborting the request
            if (!isAbortError(err)) {
                this.fire(new ErrorEvent(ensureError(err)));
            }
        }
    }

    loaded(): boolean {
        return this._loaded;
    }

    onAdd(map: Map): void {
        this.map = map;
        this.load();
    }

    onRemove(): void {
        if (this._tileJSONRequest) {
            this._tileJSONRequest.abort();
            this._tileJSONRequest = null;
        }
    }

    setSourceProperty(callback: Function): void {
        if (this._tileJSONRequest) {
            this._tileJSONRequest.abort();
            this._tileJSONRequest = null;
        }

        callback();

        this.load(true);
    }

    /**
     * Sets the source `tiles` property and re-renders the map.
     *
     * @param tiles - An array of one or more tile source URLs, as in the raster tiles spec (See the [Style Specification](https://maplibre.org/maplibre-style-spec/)
     */
    setTiles(tiles: string[]): this {
        this.setSourceProperty(() => {
            this.tiles = tiles;
            this._options.tiles = tiles;
        });

        return this;
    }

    /**
     * Sets the source `url` property and re-renders the map.
     *
     * @param url - A URL to a TileJSON resource. Supported protocols are `http:` and `https:`.
     */
    setUrl(url: string): this {
        this.setSourceProperty(() => {
            this.url = url;
            this._options.url = url;
        });

        return this;
    }

    serialize(): RasterSourceSpecification | RasterDEMSourceSpecification {
        return extend({}, this._options);
    }

    /**
     * Sets whether alpha premultiplication is applied to raster tile images.
     * Set to `false` to preserve exact RGBA byte values when alpha carries data instead of opacity.
     *
     * @param premultiplyAlpha - If `false`, disables alpha premultiplication for raster tile image decode and texture upload.
     * @example
     * ```ts
     * map.getSource<RasterTileSource>('raster-source').setPremultiplyAlpha(false);
     * ```
     */
    setPremultiplyAlpha(premultiplyAlpha: boolean): this {
        if (this._premultiplyAlpha === premultiplyAlpha) return this;

        this.setSourceProperty(() => {
            this._premultiplyAlpha = premultiplyAlpha;
        });

        return this;
    }

    hasTile(tileID: OverscaledTileID): boolean {
        return !this.tileBounds || this.tileBounds.contains(tileID.canonical);
    }

    async loadTile(tile: Tile): Promise<void> {
        const url = tile.tileID.canonical.url(this.tiles, this.map.getPixelRatio(), this.scheme);
        const premultiply = this._premultiplyAlpha;
        const imageBitmapOptions = premultiply ? undefined : {premultiplyAlpha: 'none'} as const;
        tile.abortController = new AbortController();
        try {
            const response = await ImageRequest.transformAndGetImage(
                this.map._requestManager,
                url,
                ResourceType.Tile,
                tile.abortController,
                this.map._refreshExpiredTiles,
                imageBitmapOptions
            );
            delete tile.abortController;
            if (tile.aborted) {
                tile.state = 'unloaded';
                return;
            }
            if (response) {
                if (this.map._refreshExpiredTiles && (response.cacheControl || response.expires)) {
                    tile.setExpiryData({cacheControl: response.cacheControl, expires: response.expires});
                }
                const context = this.map.painter.context;
                const gl = context.gl;
                // An empty response (e.g. HTTP 204) is a tile that exists but has no content:
                // it is drawn as fully transparent, which keeps it distinct from a missing
                // tile (404), where the parent tile shows through instead.
                const img = response.data ?? new RGBAImage({width: 1, height: 1}, new Uint8Array(4));
                tile.texture = this.map.painter.getTileTexture(img.width);
                if (tile.texture) {
                    tile.texture.update(img, {useMipmap: true, premultiply});
                } else {
                    tile.texture = new Texture(context, img, gl.RGBA, {useMipmap: true, premultiply});
                    tile.texture.bind(gl.LINEAR, gl.CLAMP_TO_EDGE, gl.LINEAR_MIPMAP_NEAREST);
                }
                tile.state = 'loaded';
            }
        } catch (err) {
            delete tile.abortController;
            if (tile.aborted) {
                tile.state = 'unloaded';
            } else if (err) {
                tile.state = 'errored';
                throw err;
            }
        }
    }

    async abortTile(tile: Tile): Promise<void> {
        if (tile.abortController) {
            tile.abortController.abort();
            delete tile.abortController;
        }
    }

    async unloadTile(tile: Tile): Promise<void> {
        if (tile.texture) {
            this.map.painter.saveTileTexture(tile.texture);
        }
    }

    hasTransition(): boolean {
        return false;
    }
}
